package java1;

import java.io.File;

public class ImageCrawel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       String scoreurl = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2022%202015%2015:30:29%20GMT+0800%20(%D6%D0%B9%FA%B1%EA%D7%BC%CA%B1%BC%E4)";
       while(true){
    	   String cookie ="JSESSIONID=3713236117801E280672EB33D10E6C6B.tomcat2";
    	   String fileName ="assignment1.html";
    	   HttpRequest response = HttpRequest.get(scoreurl);
    	       response.header("Cookie",cookie);
    	   if((response).ok()){
    	       response.receive(new File(fileName));
    	       System.out.println("ok");
    	   }
	}
}
}